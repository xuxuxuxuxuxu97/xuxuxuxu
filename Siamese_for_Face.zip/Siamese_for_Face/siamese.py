import torch
import torch.nn as nn
from torchvision import models
import torch.nn.functional as F

vgg16 = models.vgg16(pretrained=True)
# 获取VGG16的特征提取层
vgg = vgg16.features


def get_img_output_length(width, height):
    def get_output_length(input_length):
        # input_length += 6
        filter_sizes = [2, 2, 2, 2, 2]
        padding = [0, 0, 0, 0, 0]
        stride = 2
        for i in range(5):
            input_length = (input_length + 2 * padding[i] - filter_sizes[i]) // stride + 1
        return input_length

    return get_output_length(width) * get_output_length(height)


class SiameseNetwork(nn.Module):
    def __init__(self, input_shape):
        super(SiameseNetwork, self).__init__()

        self.vgg = vgg

        flat_shape = 512 * get_img_output_length(input_shape[1], input_shape[0])
        # flat_shape = 1000
        self.fc = nn.Sequential(
            nn.Linear(flat_shape, 512),
            nn.ReLU(inplace=True),

            nn.Linear(512, 256),
            nn.ReLU(inplace=True),

            nn.Linear(256, 1))

    def forward_once(self, x):
        output = self.vgg(x)
        output = torch.flatten(output, 1)
        # output = output.view(output.size()[0], -1)
        # output = self.fc(output)
        return output

    def forward(self, input1, input2):
        output1 = self.forward_once(input1)
        output2 = self.forward_once(input2)
        output = output1 - output2
        output = self.fc(output)
        # output = nn.Sigmoid(output)
        return output
