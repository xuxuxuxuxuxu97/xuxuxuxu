SiameseNetwork for face recognitation in Pytorch

unzip the data 

use train.py to train

use test.py to test

采用vgg16作为特征提取网络，采用ORL人脸数据集；

相似的图片标签为1，不相似的图片标签为0；

利用sigmoid输出的结果作为相似的可能性；

损失函数采用BCEWithLogitsLoss